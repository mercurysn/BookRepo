﻿using NUnit.Framework;
using PropertyImporter.Data.Repositories;

namespace PropertyImporter.IntegrationTest
{
    [TestFixture]
    public class DatabaseAccessTests
    {
        [Test]
        public void Test()
        {
            
        }
    }
}
